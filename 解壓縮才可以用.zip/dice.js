﻿var Discord = require('discord.io');
var logger = require('winston');
var auth = require('./auth.json');
// Configure logger settings
logger.remove(logger.transports.Console);
logger.add(new logger.transports.Console, {
    colorize: true
});
logger.level = "debug";
// Initialize Discord Bot
var bot = new Discord.Client({
   token: auth.token,
   autorun: true
});
bot.on("ready", function (evt) {
    logger.info("Connected");
    logger.info("Logged in as: ");
    logger.info(bot.username + " - (" + bot.id + ")");
});
bot.on("message", function (user, userID, channelID, message, evt) {
if (message.substring(0, 1) == '!') {
        var args = message.substring(1).split(' ');
        var cmd = args[0];

//主要修改的部分
var ran = Math.floor(Math.random()*100)+1;
        switch(cmd) {
            case 'lottery':
                bot.sendMessage({
                    to: channelID,
                    message: user + ' \u62bd\u5230\u4e86 ' + ran + ' \u0021'
                });
            break;
            case 'IP':
                bot.sendMessage({
                    to: channelID,
                    message: user + ' \u4f3a\u670d\u5668\u7684\u0049\u0050\u662f\uff1a\u006d\u0063\u002e\u0061\u006c\u0061\u006e\u0034\u0030\u0034\u0030\u0035\u002e\u0074\u0061\u0069\u0070\u0065\u0069'
                });
            break;
            case 'ip':
                bot.sendMessage({
                    to: channelID,
                    message: user + ' \u4f3a\u670d\u5668\u7684\u0049\u0050\u662f\uff1a\u006d\u0063\u002e\u0061\u006c\u0061\u006e\u0034\u0030\u0034\u0030\u0035\u002e\u0074\u0061\u0069\u0070\u0065\u0069'
                });
            break;
            case 'link':
                bot.sendMessage({
                    to: channelID,
                    message: user + ' \u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0064\u0069\u0073\u0063\u006f\u0072\u0064\u002e\u0067\u0067\u002f\u004b\u0055\u007a\u004e\u0044\u006a\u0065'
                });
            break;
            case 'web':
                bot.sendMessage({
                    to: channelID,
                    message: user + ' \u0068\u0074\u0074\u0070\u003a\u002f\u002f\u006d\u0063\u002e\u0061\u006c\u0061\u006e\u0034\u0030\u0034\u0030\u0035\u002e\u0074\u0061\u0069\u0070\u0065\u0069\u003a\u0038\u0031\u002f\u0077\u006f\u0072\u0064\u0070\u0072\u0065\u0073\u0073\u002f\u003f\u0070\u0061\u0067\u0065\u005f\u0069\u0064\u003d\u0038\u0031'
                });
            break;
            case 'help':
                bot.sendMessage({
                    to: channelID,
                    message: user + ' \u0021\u0077\u0065\u0062\u0020\u67e5\u770b\u4f3a\u670d\u5668\u7db2\u7ad9\u0020\u0021\u0049\u0050\u003a\u4f3a\u670d\u5668\u7684\u0069\u0070\u0020\u0021\u006c\u0069\u006e\u006b\u0020\u67e5\u770b\u9080\u8acb\u9023\u7d50\u0020\u0021\u006c\u006f\u0074\u0074\u0065\u0072\u0079\u0020\u96a8\u6a5f\u62bd\u9078\u0031\u002d\u0031\u0030\u0030\u0020\u0021\u0063\u006f\u006f\u0070\u0065\u0072\u0061\u0074\u0069\u006f\u006e\u0020\u5408\u4f5c\u9808\u77e5\u000a\u000a'
                });
            break;
            case 'cooperation':
                bot.sendMessage({
                    to: channelID,
                    message: user + ' \u5408\u4f5c\u8acb\u6d3d\u0040\u0021\u0041\u006c\u0061\u006e\u0034\u0030\u0034\u0030\u0035\u0023\u0033\u0035\u0034\u0030\u0020\u4e0d\u53ef\u70ba\u6284\u8972\u4f3a\u670d\u5668\u0020\u81f3\u5c11\u0035\u0030\u4eba\u000a'
                });
            break;
         }

     }
});